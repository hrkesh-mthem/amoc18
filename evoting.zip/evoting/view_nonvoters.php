<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="Main.css">
</head>

<div class="rel_top">

<div class="absolute_top" style="background-color:#ff944d;  top:0px;">

<h1 style="color:black; text-align:center; margin:10px;">EVOTING </h1>
</div>

<div class ="absolute_sec_top">
<a href="Administrative.html"><button class="btn Home">HOME</button></a>
<!--<button class="btn Vote">VOTE</button>
<button class="btn Result">View Result</button>
<button class="btn Extra1">Extra</button>-->
<a href="Main.html"><button class="btn Extra1">LOGOUT</button></a>
</div>
<div class ="absolute_mid" style="height:400px;">
<h1 style="color:#663300; text-align:center; margin:10px;">Welcome to the Online Voting System</h1>
<hr width="85%">
<center>
<iframe src="view_nonvoters1.php" name="yas" height="300" width="700"></iframe>
</center>
</div>


</html>


















































